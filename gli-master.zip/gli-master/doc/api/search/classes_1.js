var searchData=
[
  ['gl',['gl',['../a00002.html',1,'gli']]]
];
