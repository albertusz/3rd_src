#ifndef S390_FEATURES_H_
#define S390_FEATURES_H_

extern int s390_cpu_has_vx;

void Z_INTERNAL s390_check_features(void);

#endif
